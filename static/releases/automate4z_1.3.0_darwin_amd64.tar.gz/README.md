# automate4z

[![Release](https://img.shields.io/github/v/release/zarafa-dev-io/automate4z)](https://github.com/zarafa-dev-io/automate4z/releases/latest)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue)](LICENSE)
[![Go](https://img.shields.io/badge/go-1.22+-blue)](https://go.dev)

> **v1.1.0 — z/OS tasks stable.** Build complete COBOL pipelines against a real mainframe. Workflows written against v1.0 remain valid through v2.0.

automate4z (`a4z`) is an open-source workflow orchestrator written in Go that bridges the gap between z/OS mainframe execution and local execution, for COBOL developers transitioning to modern DevOps practices.

Distributed as a **single binary** (`a4z`) for Linux, macOS, and Windows (amd64/arm64), with no runtime required. Workflows are defined in YAML with syntax inspired by GitHub Actions but adapted for the mainframe context.

---

## Installation

### Linux / macOS

```bash
curl -L https://github.com/zarafa-dev-io/automate4z/releases/download/v1.1.0/automate4z_Linux_x86_64.tar.gz | tar xz
sudo mv a4z /usr/local/bin/
a4z --version
```

### Windows

Download `automate4z_Windows_x86_64.zip` from the [Releases page](https://github.com/zarafa-dev-io/automate4z/releases/latest), extract, and add `a4z.exe` to your PATH.

### Build from source (Go 1.22+)

```bash
git clone https://github.com/zarafa-dev-io/automate4z.git
cd automate4z
go build -o a4z ./cmd/a4z
```

Checksums (SHA-256) are provided in `automate4z_checksums.txt` alongside each release.

---

## Quick start

```yaml
# hello.yml
apiVersion: automate4z/v1
kind: Workflow
name: hello-world

steps:
  - id: greet
    uses: shell
    with:
      run: echo "Hello from automate4z v1.0!"

  - id: fetch
    uses: http
    with:
      url: https://httpbin.org/get
      method: GET
```

```bash
a4z run hello.yml
a4z lint hello.yml
a4z plan hello.yml
```

---

## 16 built-in tasks

**Local**

| Task | Purpose |
|------|---------|
| `shell` | Run local commands with streaming output |
| `http` | HTTP/HTTPS requests with retry and response capture |
| `fs` | Read, write, copy, move, mkdir, remove, list files |
| `assert` | Validate workflow state with expressions |
| `json-query` | jq queries on JSON data |
| `yaml-query` | jq queries on YAML data |
| `template` | Go text/template rendering with Sprig functions |
| `convert` | Convert between JSON, YAML, and CSV |
| `archive` | Create tar, tar.gz, tar.bz2, tar.xz, zip archives |
| `extract` | Extract archives with zip-slip protection |
| `wait` | Poll until: file appears, HTTP responds, TCP connects, expression is true |
| `git` | Clone, checkout, status, log |
| `notify` | Send notifications via email (SMTP) or webhook |

**z/OS**

| Task | Purpose |
|------|---------|
| `z-deps` | Resolve and cache COBOL module dependencies from GitHub Releases |
| `zos-datasets` | Upload, download, create, delete, list MVS datasets and USS files |
| `zos-jobs` | Submit JCL, monitor JES queue, retrieve SYSOUT, list spool files |

---

## z/OS workflows

automate4z connects to z/OS via z/OSMF — no mainframe agent to install. Credentials are resolved in this order: CLI flags → environment variables (`A4Z_ZOS_*`) → Zowe profile (`~/.zowe/zowe.config.json`) → default Zowe profile.

```bash
# Run a workflow against z/Xplore (free IBM z/OS sandbox)
export A4Z_ZOS_HOST=<zxplore-host>
export A4Z_ZOS_USER=Z79863
export A4Z_ZOS_PASSWORD=...
export A4Z_ZOS_HLQ=Z79863
export A4Z_ZOS_REJECT_UNAUTHORIZED=false

a4z run examples/cobol-build-pipeline.yml \
  --input module=HELLO \
  --input hlq=Z79863
```

New to z/Xplore? Follow the step-by-step tutorial in [docs/testing-with-zxplore.md](docs/testing-with-zxplore.md) — from account creation to first compiled COBOL in under 30 minutes.

---

## Usage

```bash
a4z run   workflow.yml [--input k=v] [--parallelism N] [--log-format json]
a4z lint  workflow.yml [--format json]
a4z plan  workflow.yml [--input k=v]
a4z version
```

---

## Documentation

| Document | Description |
|----------|-------------|
| [Getting started](docs/getting-started.md) | Installation, commands, tasks, expressions, secrets |
| [Workflow spec](docs/automate4z-workflow-spec.md) | Formal YAML specification |
| [Task reference](docs/automate4z-task-reference.md) | All 16 built-in tasks in detail |
| [z/Xplore guide](docs/testing-with-zxplore.md) | Run workflows against a free IBM z/OS sandbox |
| [Release notes v1.1.0](docs/releases/v1.1.0.md) | What's new in v1.1 — z/OS tasks stable |
| [Release notes v1.0.0](docs/releases/v1.0.0.md) | First production-ready release |
| [PRD](docs/automate4z-PRD.md) | Product vision and roadmap |

---

## Compatibility promise

Starting with v1.0.0, any workflow valid under v1.0 will remain valid through v2.0.0. We will not change or remove any v1.0 YAML syntax without a major version bump and a deprecation cycle.

---

## Contributing

Issues and pull requests welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) (coming soon) for guidelines.

## License

Apache 2.0 — see [LICENSE](LICENSE).
